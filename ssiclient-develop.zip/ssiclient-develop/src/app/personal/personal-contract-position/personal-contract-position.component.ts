import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ssi-personal-contract-position',
  templateUrl: './personal-contract-position.component.html',
  styleUrls: ['./personal-contract-position.component.scss']
})
export class PersonalContractPositionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
