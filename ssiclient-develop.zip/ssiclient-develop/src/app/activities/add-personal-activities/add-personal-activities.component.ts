import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ssi-add-personal-activities',
  templateUrl: './add-personal-activities.component.html',
  styleUrls: ['./add-personal-activities.component.scss']
})
export class AddPersonalActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
