export interface Type {
    name: string;
}