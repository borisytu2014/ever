export interface City{
    name: string;
}
