export interface Equipment {
  id: number;
  name: string;
  description: string;
  type: number;
  image: string|any;
}
