export interface LoginResult {
  token: string;
  success: string;
}
