export const STATUS_CODES = {
        OK: 200,
        BAD: 400
};
