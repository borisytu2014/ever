export interface PositionData {
  id: number;
  name: string;
  description: string;
  level: number;
  nameParentPosition: string;
  idParentPosition: number;
}
