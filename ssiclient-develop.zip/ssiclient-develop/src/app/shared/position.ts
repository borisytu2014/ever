export interface Position {
  id: number;
  name: string;
  description: string;
  level: number;
  nameParentPosition: string;
  idParentPosition: number;
  nombreFunctions: string;
}
