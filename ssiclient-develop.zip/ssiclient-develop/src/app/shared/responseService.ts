export interface ResponseService {
  status: string;
  data: object[];
}
