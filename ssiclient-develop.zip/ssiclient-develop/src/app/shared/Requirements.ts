export interface Requirements {
  id: string;
  name: string;
  description: string;
  position_position_id: string;
  positionName: string;
}
