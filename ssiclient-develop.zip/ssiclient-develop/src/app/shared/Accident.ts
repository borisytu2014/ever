export interface Accident {
  id: number;
  fecha: string;
  descripcion: string;
}
