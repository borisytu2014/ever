export interface Activity {
  id: number;
  detailActivities: string;
  detailGoal: string;
  detailType: string;
}

