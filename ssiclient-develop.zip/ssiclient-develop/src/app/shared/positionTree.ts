export interface PositionTree {
  id: number;
  name: string;
  isExpanded: boolean;
  nombreFunctions: string;
  children: {};
}
