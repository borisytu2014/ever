export interface Resource {
  id: number;
  resourceCost: string;
  resourceDetail: string;
}
