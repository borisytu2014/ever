export interface ReportIncidentEtl {
  numIncidents: number;
  type: string;
  areaName: string;
}
