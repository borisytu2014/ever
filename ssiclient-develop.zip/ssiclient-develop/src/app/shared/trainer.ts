export interface Trainer {
  id: number;
  name: string;
  ci: string;
  speciality: string;
  skillsDescriptions: string;
  image: string;
  /*activitiesSsos:*/
}
