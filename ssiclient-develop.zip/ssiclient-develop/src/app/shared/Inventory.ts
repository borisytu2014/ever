export interface Inventory {
  id: number;
  idEquipment: number;
  idPersonal: number;
  dateAsigment: string;
  status: string;
  active: boolean;

}
