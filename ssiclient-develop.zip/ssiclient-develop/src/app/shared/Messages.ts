export const MSG_PERSONAL_DELETED = 'El personal ha sido eliminado con exito';
export const TITLE_MSG_PERSONAL = 'PERSONAL INFORMACION';
export const MSG_PERSONAL_CREATED = 'El personal ha sido creado con exito';
export const TITLE_MSG_LOGIN = 'LOGIN INFORMACION';
export const MSG_LOGIN_CORRECTO = 'El usuario es correcto';

export const ERROR_MSG = 'Ha ocurrido un error inesperado';
export const ERROR_UNKNOW = 'Error desconocido';

export const TITLE_MSG_CONTRACT = 'CONTRACT';
export const MSG_CONTRACT_BODY_DELETE  = 'El contrato ha sido eliminado con exito';
export const MSG_CONTRACT_BODY_UPDATE  = 'El contrato ha sido modificado con exito';
export const TITLE_MSG_USER = 'USER';
export const MSG_USER_BODY_CREATED = 'El usuarios a sido creado con exito';
export const MSG_USER_BODY_UPDATE = 'El usuarios a sido actualizado con exito'; 
export const MSG_USER_BODY_DELETE = 'El usuarios a sido eliminado con exito'; 



