export interface Personal {
  id: number;
  name: string;
  lastName: string;
  email: string;
  address: string;
  telephone: number;
  datebirth: string;
  image: string;
}
