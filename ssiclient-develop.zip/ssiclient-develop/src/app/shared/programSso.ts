export interface ProgramSso {
  id: number;
  ssoObjetive: string;
  ssoIndicator: string;
  ssoGoal: string;
  ssoExecutionTime: string;
  ssoResponsable: string;
  ssoTotalCost: number;
}




