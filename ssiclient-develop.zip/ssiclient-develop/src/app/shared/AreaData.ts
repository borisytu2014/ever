export interface AreaData {
  id: number;
  name: string;
  description: string;
}
