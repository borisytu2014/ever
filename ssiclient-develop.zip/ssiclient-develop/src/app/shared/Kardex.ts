export interface Kardex {
  id: number;
  idEquipament: number;
  dateKardex: string;
  entryKardex: number;
  outlayKardex: number;
  balanceKardex: number;
}
