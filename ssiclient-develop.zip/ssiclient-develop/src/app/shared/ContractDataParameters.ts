import { Injectable } from '@angular/core';

@Injectable()
export class ContractDataParameters {
  public contractUpdate: any;

  public constructor() { }
}
