import { Injectable } from '@angular/core';

@Injectable()
export class FunctionsDataParameters {
  public functionsUpdate: any;

  public constructor() { }
}
