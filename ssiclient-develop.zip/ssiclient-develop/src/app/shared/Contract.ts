export interface Contract {
  id: string;
  code: string;
  city: string;
  date: string;
  description: string;
  salary: string;
  type: string;
}
