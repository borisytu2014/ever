import { Injectable } from '@angular/core';

@Injectable()
export class RequirementsDataParameters {
  public requirementsUpdate: any;

  public constructor() { }
}
