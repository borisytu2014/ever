export interface Department {
  id: number;
  name: string;
  description: string;
  positions: Position[];
}
