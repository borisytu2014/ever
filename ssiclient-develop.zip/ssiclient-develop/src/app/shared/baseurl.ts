export const baseURL = 'http://localhost:8080';
export const API_URL = '/api/v1';
export const baseURLETL = 'http://localhost:8082';
