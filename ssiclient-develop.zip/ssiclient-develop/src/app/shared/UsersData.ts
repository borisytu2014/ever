export interface UsersData {
    id: number;
    username: string;
    password: string;
    userActive : boolean;
  }
  