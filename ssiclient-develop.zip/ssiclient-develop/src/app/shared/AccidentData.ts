export interface AccidentData {
  id: number;
  fecha: string;
  descripcion: string;
}
