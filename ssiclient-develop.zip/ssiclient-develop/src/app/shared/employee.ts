export interface Employee {
  id: number;
  name: string;
  image: string;
  jobPosition: string;
  jobCode: string;
  featured: boolean;
  jobDescription: string;
}
