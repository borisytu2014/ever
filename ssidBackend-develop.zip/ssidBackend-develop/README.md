# API del back end del GRUPO D
Esta es la version 0.1 del proyecto del GRUPO D 

# Tecnologias

* Spring Boot 2.0
* Java 1.8
* SQL Server

# Caracteristicas

* Spring Security 
* JSON WEB TOKEN (JWT) para asegurar los end points
* Generacion de capas para un desarrollo escalable y mantenible (controller, service, repository, domain, command)
* coneccion a base de datos mssql server 

# Integrantes
* Jesus David Piérola Alvarado
* Marcos Bustos Jimenez
* Boris Gonzalo Medrano Guzman
* Vanessa Alcocer Iriarte
* Franz Alberto Lopez Choque
* Ivan Misericordia Eulate
* Christian Marcelo Tola Pacheco
* Gilmer Daniel Fernandez Pinto
