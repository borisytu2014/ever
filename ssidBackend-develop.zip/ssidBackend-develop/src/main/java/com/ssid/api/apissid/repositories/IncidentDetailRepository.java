package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.IncidentDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncidentDetailRepository extends JpaRepository<IncidentDetail, Long> {

}
