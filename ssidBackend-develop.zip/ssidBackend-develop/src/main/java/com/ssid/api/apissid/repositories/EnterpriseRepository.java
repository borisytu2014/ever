package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.Enterprise;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnterpriseRepository extends JpaRepository<Enterprise, Long> {
}


