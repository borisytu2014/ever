package com.ssid.api.apissid.domain;

public class ModelBaseAuditHistory {
}
