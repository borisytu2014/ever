package com.ssid.api.apissid.services;

import com.ssid.api.apissid.domain.RiskIperc;
import com.ssid.api.apissid.domain.RiskIpercDetail;

import java.util.List;

public interface RiskIpercDetailService extends GenericService<RiskIpercDetail>  {
}
