package com.ssid.api.apissid.services;

import com.ssid.api.apissid.domain.IncidentType;

import java.util.List;

public interface IncidentTypeService {

    List<IncidentType> getListIncidentType();
}
