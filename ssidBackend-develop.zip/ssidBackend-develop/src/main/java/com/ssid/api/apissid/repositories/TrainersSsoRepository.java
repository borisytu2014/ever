package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.TrainersSso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainersSsoRepository extends JpaRepository<TrainersSso, Long> {
}
