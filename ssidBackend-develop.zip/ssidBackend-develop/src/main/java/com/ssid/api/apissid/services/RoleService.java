package com.ssid.api.apissid.services;
/**
 * @author Borisytu
 */
import com.ssid.api.apissid.domain.Role;

import java.util.List;

public interface RoleService {
    List<Role> getAllRoles();
}

