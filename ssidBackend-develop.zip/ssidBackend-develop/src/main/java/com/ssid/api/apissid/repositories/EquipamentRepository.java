package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.Equipament;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipamentRepository extends JpaRepository<Equipament, Long>{
}
