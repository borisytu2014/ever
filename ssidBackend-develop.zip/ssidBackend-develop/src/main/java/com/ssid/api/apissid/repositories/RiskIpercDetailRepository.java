package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.RiskIpercDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskIpercDetailRepository extends JpaRepository<RiskIpercDetail, Long> {
}
