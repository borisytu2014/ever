package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.CausingAgent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CausingAgentRepository extends JpaRepository<CausingAgent, Long> {
}
