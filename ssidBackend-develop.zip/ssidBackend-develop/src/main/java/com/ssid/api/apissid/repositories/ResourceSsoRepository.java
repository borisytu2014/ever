package com.ssid.api.apissid.repositories;
import com.ssid.api.apissid.domain.ResourceSso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResourceSsoRepository extends JpaRepository<ResourceSso, Long>{


}
