package com.ssid.api.apissid.repositories;

import com.ssid.api.apissid.domain.ActivitiesSso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActivitiesSsoRepository extends JpaRepository<ActivitiesSso, Long> {

}
