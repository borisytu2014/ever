package com.ssid.api.apissid.services;

import com.ssid.api.apissid.domain.IncidentDetail;

import java.util.List;

public interface IncidentDetailService {
    List<IncidentDetail> getAllIncidentDetail();
}
