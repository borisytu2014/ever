package com.ssid.api.apissid.services;

import com.ssid.api.apissid.domain.CausingAgent;

public interface CausingAgentService extends GenericService<CausingAgent>{
}
